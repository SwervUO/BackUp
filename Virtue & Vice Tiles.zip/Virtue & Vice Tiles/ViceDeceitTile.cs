using System;
using Server;

namespace Server.Items
{
	public class ViceDeceitTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceDeceitTileSouthDeed(); } }

		[Constructable]
		public ViceDeceitTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x99D4 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99D5 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99D6 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99D7 ), 1, 1, 0 );
			  Name = "Vice Deceit Floor South";
		}

		public ViceDeceitTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceDeceitTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceDeceitTileSouthAddon(); } }

		[Constructable]
		public ViceDeceitTileSouthDeed()
		{
			  Name = "Vice Deceit Floor South Deed";
		}

		public ViceDeceitTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceDeceitTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceDeceitTileEastDeed(); } }

		[Constructable]
		public ViceDeceitTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x99D8 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99D9 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99DA ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99DB ), 1, 1, 0 );
			  Name = "Vice Deceit Floor East";
		}

		public ViceDeceitTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceDeceitTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceDeceitTileEastAddon(); } }

		[Constructable]
		public ViceDeceitTileEastDeed()
		{
			  Name = "Vice Deceit Floor East Deed";
		}

		public ViceDeceitTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
using System;
using Server;

namespace Server.Items
{
	public class ChaosTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ChaosTileEastDeed(); } }

		[Constructable]
		public ChaosTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14E3 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14E4 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14E5 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14E6 ), 1, 0, 0 );
			  Name = "Chaos Floor East";
		}

		public ChaosTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ChaosTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ChaosTileEastAddon(); } }

		[Constructable]
		public ChaosTileEastDeed()
		{
			  Name = "Chaos Floor East Deed";
		}

		public ChaosTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
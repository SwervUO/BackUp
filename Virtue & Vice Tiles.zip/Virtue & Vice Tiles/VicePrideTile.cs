using System;
using Server;

namespace Server.Items
{
	public class VicePrideTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VicePrideTileSouthDeed(); } }

		[Constructable]
		public VicePrideTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x99F4 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99F5 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99F6 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99F7 ), 1, 1, 0 );
			  Name = "Vice Pride Floor South";
		}

		public VicePrideTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VicePrideTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VicePrideTileSouthAddon(); } }

		[Constructable]
		public VicePrideTileSouthDeed()
		{
			  Name = "Vice Pride Floor South Deed";
		}

		public VicePrideTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VicePrideTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VicePrideTileEastDeed(); } }

		[Constructable]
		public VicePrideTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x99F8 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99F9 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99FA ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99FB ), 1, 1, 0 );
			  Name = "Vice Pride Floor East";
		}

		public VicePrideTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VicePrideTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VicePrideTileEastAddon(); } }

		[Constructable]
		public VicePrideTileEastDeed()
		{
			  Name = "Vice Pride Floor East Deed";
		}

		public VicePrideTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
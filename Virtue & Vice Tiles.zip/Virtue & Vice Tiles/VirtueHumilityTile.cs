using System;
using Server;

namespace Server.Items
{
	public class VirtueHumilityTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueHumilityTileEastDeed(); } }

		[Constructable]
		public VirtueHumilityTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14CF ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14D0 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14D1 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14D2 ), 1, 0, 0 );
			  Name = "Virtue Humility Floor East";
		}

		public VirtueHumilityTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHumilityTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueHumilityTileEastAddon(); } }

		[Constructable]
		public VirtueHumilityTileEastDeed()
		{
			  Name = "Virtue Humility Floor East Deed";
		}

		public VirtueHumilityTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHumilityTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueHumilityTileSouthDeed(); } }

		[Constructable]
		public VirtueHumilityTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14D3 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14D4 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14D5 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14D6 ), 1, 0, 0 );
			Name = "Virtue Humility Floor South";
		}

		public VirtueHumilityTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHumilityTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueHumilityTileSouthAddon(); } }

		[Constructable]
		public VirtueHumilityTileSouthDeed()
		{
			  Name = "Virtue Humility Floor South Deed";
		}

		public VirtueHumilityTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
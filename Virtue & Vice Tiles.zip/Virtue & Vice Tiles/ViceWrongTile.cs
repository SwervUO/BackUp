using System;
using Server;

namespace Server.Items
{
	public class ViceWrongTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceWrongTileSouthDeed(); } }

		[Constructable]
		public ViceWrongTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x9A04 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x9A05 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x9A06 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x9A07 ), 1, 1, 0 );
			  Name = "Vice Wrong Floor South";
		}

		public ViceWrongTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceWrongTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceWrongTileSouthAddon(); } }

		[Constructable]
		public ViceWrongTileSouthDeed()
		{
			  Name = "Vice Wrong Floor South Deed";
		}

		public ViceWrongTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceWrongTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceWrongTileEastDeed(); } }

		[Constructable]
		public ViceWrongTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x9A08 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x9A09 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x9A0A ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x9A0B ), 1, 1, 0 );
			  Name = "Vice Wrong Floor East";
		}

		public ViceWrongTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceWrongTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceWrongTileEastAddon(); } }

		[Constructable]
		public ViceWrongTileEastDeed()
		{
			  Name = "Vice Wrong Floor East Deed";
		}

		public ViceWrongTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
using System;
using Server;

namespace Server.Items
{
	public class VirtueSacrificeTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueSacrificeTileEastDeed(); } }

		[Constructable]
		public VirtueSacrificeTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x150A ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x150B ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x150C ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x150D ), 1, 0, 0 );
			  Name = "Virtue Sacrifice Floor East";
		}

		public VirtueSacrificeTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueSacrificeTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueSacrificeTileEastAddon(); } }

		[Constructable]
		public VirtueSacrificeTileEastDeed()
		{
			  Name = "Virtue Sacrifice Floor East Deed";
		}

		public VirtueSacrificeTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueSacrificeTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueSacrificeTileSouthDeed(); } }

		[Constructable]
		public VirtueSacrificeTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x150E ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x150F ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x1510 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x1511 ), 1, 0, 0 );
			Name = "Virtue Sacrifice Floor South";
		}

		public VirtueSacrificeTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueSacrificeTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueSacrificeTileSouthAddon(); } }

		[Constructable]
		public VirtueSacrificeTileSouthDeed()
		{
			  Name = "Virtue Sacrifice Floor South Deed";
		}

		public VirtueSacrificeTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
using System;
using Server;

namespace Server.Items
{
	public class VirtueCompassionTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueCompassionTileEastDeed(); } }

		[Constructable]
		public VirtueCompassionTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14A7 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14A8 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14A9 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14AA ), 1, 0, 0 );
			  Name = "Virtue Compassion Floor East";
		}

		public VirtueCompassionTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueCompassionTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueCompassionTileEastAddon(); } }

		[Constructable]
		public VirtueCompassionTileEastDeed()
		{
			  Name = "Virtue Compassion Floor East Deed";
		}

		public VirtueCompassionTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueCompassionTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueCompassionTileSouthDeed(); } }

		[Constructable]
		public VirtueCompassionTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14AB ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14AC ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14AD ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14AE ), 1, 0, 0 );
			Name = "Virtue Compassion Floor South";
		}

		public VirtueCompassionTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueCompassionTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueCompassionTileSouthAddon(); } }

		[Constructable]
		public VirtueCompassionTileSouthDeed()
		{
			  Name = "Virtue Compassion Floor South Deed";
		}

		public VirtueCompassionTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
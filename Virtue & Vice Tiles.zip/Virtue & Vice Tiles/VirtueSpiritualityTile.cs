using System;
using Server;

namespace Server.Items
{
	public class VirtueSpiritualityTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueSpiritualityTileEastDeed(); } }

		[Constructable]
		public VirtueSpiritualityTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14BF ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14C0 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14C1 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14C2 ), 1, 0, 0 );
			  Name = "Virtue Spirituality Floor East";
		}

		public VirtueSpiritualityTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueSpiritualityTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueSpiritualityTileEastAddon(); } }

		[Constructable]
		public VirtueSpiritualityTileEastDeed()
		{
			  Name = "Virtue Spirituality Floor East Deed";
		}

		public VirtueSpiritualityTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueSpiritualityTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueSpiritualityTileSouthDeed(); } }

		[Constructable]
		public VirtueSpiritualityTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14C3 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14C4 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14C5 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14C6 ), 1, 0, 0 );
			Name = "Virtue Spirituality Floor South";
		}

		public VirtueSpiritualityTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueSpiritualityTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueSpiritualityTileSouthAddon(); } }

		[Constructable]
		public VirtueSpiritualityTileSouthDeed()
		{
			  Name = "Virtue Spirituality Floor South Deed";
		}

		public VirtueSpiritualityTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
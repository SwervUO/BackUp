using System;
using Server;

namespace Server.Items
{
	public class VirtueHonestyTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueHonestyTileEastDeed(); } }

		[Constructable]
		public VirtueHonestyTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x149F ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14A0 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14A1 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14A2 ), 1, 0, 0 );
			  Name = "Virtue Honesty Floor East";
		}

		public VirtueHonestyTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHonestyTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueHonestyTileEastAddon(); } }

		[Constructable]
		public VirtueHonestyTileEastDeed()
		{
			  Name = "Virtue Honesty Floor East Deed";
		}

		public VirtueHonestyTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHonestyTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueHonestyTileSouthDeed(); } }

		[Constructable]
		public VirtueHonestyTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14A3 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14A4 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14A5 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14A6 ), 1, 0, 0 );
			Name = "Virtue Honesty Floor South";
		}

		public VirtueHonestyTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHonestyTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueHonestyTileSouthAddon(); } }

		[Constructable]
		public VirtueHonestyTileSouthDeed()
		{
			  Name = "Virtue Honesty Floor South Deed";
		}

		public VirtueHonestyTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
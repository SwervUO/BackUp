using System;
using Server;

namespace Server.Items
{
	public class VirtueJusticeTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueJusticeTileEastDeed(); } }

		[Constructable]
		public VirtueJusticeTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14AF ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14B0 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14B1 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14B2 ), 1, 0, 0 );
			  Name = "Virtue Justice Floor East";
		}

		public VirtueJusticeTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueJusticeTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueJusticeTileEastAddon(); } }

		[Constructable]
		public VirtueJusticeTileEastDeed()
		{
			  Name = "Virtue Justice Floor East Deed";
		}

		public VirtueJusticeTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueJusticeTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueJusticeTileSouthDeed(); } }

		[Constructable]
		public VirtueJusticeTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14B3 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14B4 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14B5 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14B6 ), 1, 0, 0 );
			Name = "Virtue Justice Floor South";
		}

		public VirtueJusticeTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueJusticeTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueJusticeTileSouthAddon(); } }

		[Constructable]
		public VirtueJusticeTileSouthDeed()
		{
			  Name = "Virtue Justice Floor South Deed";
		}

		public VirtueJusticeTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
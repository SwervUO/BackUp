using System;
using Server;

namespace Server.Items
{
	public class ViceCovetousTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceCovetousTileSouthDeed(); } }

		[Constructable]
		public ViceCovetousTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x99CC ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99CD ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99CE ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99CF ), 1, 1, 0 );
			  Name = "Vice Covetous Floor South";
		}

		public ViceCovetousTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceCovetousTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceCovetousTileSouthAddon(); } }

		[Constructable]
		public ViceCovetousTileSouthDeed()
		{
			  Name = "Vice Covetous Floor South Deed";
		}

		public ViceCovetousTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceCovetousTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceCovetousTileEastDeed(); } }

		[Constructable]
		public ViceCovetousTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x99D0 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99D1 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99D2 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99D3 ), 1, 1, 0 );
			  Name = "Vice Covetous Floor East";
		}

		public ViceCovetousTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceCovetousTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceCovetousTileEastAddon(); } }

		[Constructable]
		public ViceCovetousTileEastDeed()
		{
			  Name = "Vice Covetous Floor East Deed";
		}

		public ViceCovetousTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
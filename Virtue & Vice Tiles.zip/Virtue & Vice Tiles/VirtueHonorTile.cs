using System;
using Server;

namespace Server.Items
{
	public class VirtueHonorTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueHonorTileEastDeed(); } }

		[Constructable]
		public VirtueHonorTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14C7 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14C8 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14C9 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14CA ), 1, 0, 0 );
			  Name = "Virtue Honor Floor East";
		}

		public VirtueHonorTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHonorTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueHonorTileEastAddon(); } }

		[Constructable]
		public VirtueHonorTileEastDeed()
		{
			  Name = "Virtue Honor Floor East Deed";
		}

		public VirtueHonorTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHonorTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueHonorTileSouthDeed(); } }

		[Constructable]
		public VirtueHonorTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14CB ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14CC ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14CD ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14CE ), 1, 0, 0 );
			Name = "Virtue Honor Floor South";
		}

		public VirtueHonorTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueHonorTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueHonorTileSouthAddon(); } }

		[Constructable]
		public VirtueHonorTileSouthDeed()
		{
			  Name = "Virtue Honor Floor South Deed";
		}

		public VirtueHonorTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
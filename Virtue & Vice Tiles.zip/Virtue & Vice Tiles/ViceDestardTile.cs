using System;
using Server;

namespace Server.Items
{
	public class ViceDestardTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceDestardTileSouthDeed(); } }

		[Constructable]
		public ViceDestardTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x99E4 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99E5 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99E6 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99E7 ), 1, 1, 0 );
			  Name = "Vice Destard Floor South";
		}

		public ViceDestardTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceDestardTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceDestardTileSouthAddon(); } }

		[Constructable]
		public ViceDestardTileSouthDeed()
		{
			  Name = "Vice Destard Floor South Deed";
		}

		public ViceDestardTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceDestardTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceDestardTileEastDeed(); } }

		[Constructable]
		public ViceDestardTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x99E8 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99E9 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99EA ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99EB ), 1, 1, 0 );
			  Name = "Vice Destard Floor East";
		}

		public ViceDestardTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceDestardTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceDestardTileEastAddon(); } }

		[Constructable]
		public ViceDestardTileEastDeed()
		{
			  Name = "Vice Destard Floor East Deed";
		}

		public ViceDestardTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
using System;
using Server;

namespace Server.Items
{
	public class VirtueValorTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueValorTileEastDeed(); } }

		[Constructable]
		public VirtueValorTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x14B7 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14B8 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14B9 ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14BA ), 1, 0, 0 );
			  Name = "Virtue Valor Floor East";
		}

		public VirtueValorTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueValorTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueValorTileEastAddon(); } }

		[Constructable]
		public VirtueValorTileEastDeed()
		{
			  Name = "Virtue Valor Floor East Deed";
		}

		public VirtueValorTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueValorTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new VirtueValorTileSouthDeed(); } }

		[Constructable]
		public VirtueValorTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x14BB ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x14BC ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x14BD ), 1, 1, 0 );
			AddComponent( new AddonComponent( 0x14BE ), 1, 0, 0 );
			Name = "Virtue Valor Floor South";
		}

		public VirtueValorTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class VirtueValorTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new VirtueValorTileSouthAddon(); } }

		[Constructable]
		public VirtueValorTileSouthDeed()
		{
			  Name = "Virtue Valor Floor South Deed";
		}

		public VirtueValorTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
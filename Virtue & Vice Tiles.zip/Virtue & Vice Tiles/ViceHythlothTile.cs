using System;
using Server;

namespace Server.Items
{
	public class ViceHythlothTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceHythlothTileSouthDeed(); } }

		[Constructable]
		public ViceHythlothTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x99EC ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99ED ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99EE ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99EF ), 1, 1, 0 );
			  Name = "Vice Hythloth Floor South";
		}

		public ViceHythlothTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceHythlothTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceHythlothTileSouthAddon(); } }

		[Constructable]
		public ViceHythlothTileSouthDeed()
		{
			  Name = "Vice Hythloth Floor South Deed";
		}

		public ViceHythlothTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceHythlothTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceHythlothTileEastDeed(); } }

		[Constructable]
		public ViceHythlothTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x99F0 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99F1 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99F2 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99F3 ), 1, 1, 0 );
			  Name = "Vice Hythloth Floor East";
		}

		public ViceHythlothTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceHythlothTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceHythlothTileEastAddon(); } }

		[Constructable]
		public ViceHythlothTileEastDeed()
		{
			  Name = "Vice Hythloth Floor East Deed";
		}

		public ViceHythlothTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
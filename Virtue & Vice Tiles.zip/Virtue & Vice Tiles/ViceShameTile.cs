using System;
using Server;

namespace Server.Items
{
	public class ViceShameTileSouthAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceShameTileSouthDeed(); } }

		[Constructable]
		public ViceShameTileSouthAddon()
		{
			AddComponent( new AddonComponent( 0x99FC ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x99FD ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x99FE ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x99FF ), 1, 1, 0 );
			  Name = "Vice Shame Floor South";
		}

		public ViceShameTileSouthAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceShameTileSouthDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceShameTileSouthAddon(); } }

		[Constructable]
		public ViceShameTileSouthDeed()
		{
			  Name = "Vice Shame Floor South Deed";
		}

		public ViceShameTileSouthDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceShameTileEastAddon : BaseAddon
	{
		public override BaseAddonDeed Deed{ get{ return new ViceShameTileEastDeed(); } }

		[Constructable]
		public ViceShameTileEastAddon()
		{
			AddComponent( new AddonComponent( 0x9A00 ), 0, 0, 0 ); 
			AddComponent( new AddonComponent( 0x9A01 ), 1, 0, 0 );
			AddComponent( new AddonComponent( 0x9A02 ), 0, 1, 0 );
			AddComponent( new AddonComponent( 0x9A03 ), 1, 1, 0 );
			  Name = "Vice Shame Floor East";
		}

		public ViceShameTileEastAddon( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}

	public class ViceShameTileEastDeed : BaseAddonDeed
	{
		public override BaseAddon Addon{ get{ return new ViceShameTileEastAddon(); } }

		[Constructable]
		public ViceShameTileEastDeed()
		{
			  Name = "Vice Shame Floor East Deed";
		}

		public ViceShameTileEastDeed( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
	}
}
To install the High Seas Ships :

1/ Copy the files in the Scripts folders from this package
2/ Paste them to your Scripts folder
3/ Replace the files when asked (two files need to be replaced, or if you prefer, merge them following the changes in #region HS Ships)
4/ Ready to launch


v2.02 (2015-09-11)
- The boats and galleons can now "wrap" at the end of each map (Brit, Ilsh and Tokuno).
- Fix an error in the code about docked galleons so they are displayed correctly on screen before placement.
- Link speed to the level of durability : Full Speed (66-100), Reduced Speed (34-65), Scuttled (0-33).
- Changed the condition based on durability : Pristine (100), Slightly Damaged (99->75), Moderately Damaged (74->50), Heavily Damaged (49->25), Extremely Damaged (24->0).
- The status displayed on the tillermans (mobile and item) changes now when using the mooring lines / planks to get out of the ships.
- The galleons are refreshed when getting on and out from the mooring lines.
- Major overhaul in the serialization methods. It was reported that after a while serialization errors were appearing. This should be better now with cleaner and better code.
  Watch out though : this version is not retro-compatible. If you have this system on a live server, all Ships will have to be wiped.
- Durability moved to Galleons only. Classic boats are not supposed to be damaged or repaired (on OSI).
- New Security System moved to Galleons only. Classic boats are not supposed to be secured by the new system (on OSI).
- The Tillerman for Galleons will now warn when your ship encounters an obstacle.
- When ships are deleted through serialization errors, all components now go away with the ships.
- Recall spell doesn't refresh the ships anymore.
- Include Sacred Journey spell to be able to get on ships.
- Stopping the use of the Hungarian notation and staying consistent with Microsoft's .NET Framework guidelines (which include an exception : you can prefix internal and private identifiers with an underscore).
- Revised the way packets are sent for more precise behavior and allowing the use of the multi container packet (0xF7) introduced with the smoothmovement packet (0xF6).
- The Tillerman for Galleons now refreshes when the order to stop the boat is called, making it accessible immediately(client-side) through its context menu.
- Fixed a bug with rowboats which was preventing them to go to SpeedCode.One.
- Fixed an issue with rowboats which couldn't be displayed correctly after they had moved with smooth movement.
  
v2.01 (2015-05-16)
- fix the Paint Cans so they can dye Britain Galleons too
- when Galleons stop moving, their Tillerman is refreshed so there is an instant access to them
- removed lower and raise anchor commands from the Galleons (which are supposed to work without anchors with the new security system)
- Galleons can now by dry docked even when not anchored
- increase the distance allowed to leave the Galleons through mooring lines
- decrease the distance for using the mooring lines to get on the Galleons
- security checks have been revised for better performance
- using the correct clilocs for the galleon components (thanks Dian !)
- cannot pilot while flying (thanks Dian !)
- cannot leave the galleons while it's being driven (thanks Dian !)
- you must be on board to pilot a ship (thanks Dian !)


v2.00 (2015-04-09)
- complete rework of the system to avoid core modifications
- fix tillerman context menus on classic boats
- fix the chosen direction on the deeds and dockedboats
- add the rowboat
- fix the gumps in boats and galleons deeds so they can't be opened multi times

v1.21 (2015-01-14)
- change back to the normal security settings for the classic boats (using boat keys)
- better security settings on the ships (prevent speech control if you are passenger)
- option to choose the boat direction on placement (better accuracy when placing the boat)
- messages when entering into the mouse control mode ("You are now piloting this vessel" & "You are no longer piloting this vessel")
- dry dock on context menu on the Tillerman (when not aboard)
- add dry dock to small boats
- fix an error with Transport and Sectors (that existed since the update to JustUO)
- remove the distance to use the wheel (as it's supposed to work while embarked)
- improved the smooth movement rendering (new CheckMulti variables being used in Map.cs)
- fix MultiID on Docked Galleons

v1.20 (2014-12-13)
- fix a crash from the BoolTeleport function (thx Dian)
- fixes on the wheel control (thx Dian)
- changed the new security settings for the new normal boats
- introduction of the map navigation system
- introduction of emergency repairs

v1.19 (2014-09-24)
- fixes on the boat security system : public access fixed, the possibility to rename the boat is in the context menu of the Tillerman, the boat rune is now blue :)
- fixes on the boat fight system : sounds when firing the cannons
- general galleons settings : the preview image of the galleons while placing them is not anymore damaged, the hold now looks like a hold (not a bag), galleons refresh system so they don't decay after 13 days

v1.18 (2014-07-23)
- introducing boat security settings
- fix the cannons so they update while moving the ship (and are able to fire)

v1.17 (2014-07-11)
- fix the packets sent to mobiles so that an invis GM doesn't appear to normal players
- fix Galleons so they actually sink
- change the way to fire with cannons : instantly fire (with a reload delay)
- added a mobile "BoatGunshmith" with cannonballs and cannons for the ships
- added all boats to the new Shipwright

v1.16 (2014-06-19)
- allow relative drops on the Boats after Smooth Move

v1.15 (2014-06-05)
- reducing the Orc Galleons size so players can embark/disembark from them
- fix the recall location on the Galleons so it turns with them

v1.14 (2014-05-20)
- add the possibility to redeed the cannons (to enable DryDock)

v1.13 (2014-05-07)
- fix cannons orientation when moving the Galleons
- fix the use of Hold
- fix players being able to place cannons (not only Staff)

v1.12 (2014-04-26)
- leave the commands of the boats on death or on logout
- fix recalling from key
- introducing BoatFight (not finished yet)

v1.11 (2014-04-24)
- Fix DryDock with all the Galleons
- Add all the normal boats
- The Tillerman Mobile is set to invulnerable
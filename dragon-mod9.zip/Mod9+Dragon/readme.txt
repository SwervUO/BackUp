*********************************************************************
***Go to the addon folder and look at the readme.txt file there!!!***
*********************************************************************
You will find all documentation on the Windows-Version support page. Look at www.uocm.de OR www.ryandor.com

Note #1: Create SPHERE STATICS for UOSP....
Note #2: Only 6144 x 4096 x 256 Color Bitmaps are supported.       
Note #3: Some tables are in development and work not perfect..
﻿/*
 * Crée par SharpDevelop.
 * Gargouille
 * Date: 17/11/2014
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
using System.IO;
using Server;
using Server.Mobiles;
using Server.Targeting;

using DynamicGumps;
using UltimaLive;

namespace Server.Items
{
	/// <summary>
	/// WARNING
	/// 
	/// Items and StaticTargets are added/deleted by this system, no problem
	/// 
	/// But for LandTiles, only the ID is changed
	/// 
	/// So, if you add a LandTile in a DecorumDefinition, it will becomes black if not contained with a ID in the next displayed DecorumDefinition
	/// 
	/// Make sure ALL DecorumDefinitions of a Decorum define exactly the same pool of LandTiles
	/// </summary>
	
	
	public abstract class BlackList
	{
		public static Type[] Types = new Type[]//Sensibles types that you care and don't want them to be deleted ^^
		{
			typeof(Decorum),
			typeof(Spawner)
				
		};
	}
	
	public enum FlipTo
	{
		First,
		Last,
		Next,
		Previous,
		NextNoLoop,
		PreviousNoLoop
	}
	
	[GumpHeader(Profile.Paper,IsClosable.True,"DECORUM")]
	public class Decorum : Item
	{
		#region ...ctor
		[Constructable]
		public Decorum() : base(7027)
		{
			Name = "Decorum";
			Visible = false;
			Movable = false;
		}
		#endregion
		
		#region Private
		private List<DecorumDefinition> m_Definitions = new List<DecorumDefinition>();
		private int m_DefCount { get { return m_Definitions.Count; } }
		private bool m_Empty { get { return m_DefCount==0; } }
		private DecorumDefinition m_SelectedDef;
		private DecorumDefinition m_Displayed { get { return m_Definitions.FirstOrDefault(d=>d.Displayed); } }
		private int m_DisplayedIndex { get { return m_Displayed!=null?m_Definitions.IndexOf(m_Displayed):-1; } }
		#endregion
		
		#region Public accessors
		[CommandProperty( AccessLevel.GameMaster )]
		public FlipTo FlipTo { get{ return FlipTo.First; } set{ TryDisplay(value);} }
		
		public void First()
		{
			TryDisplay(0, true);
		}
		public void Last()
		{
			TryDisplay(m_DefCount-1, true);
		}
		public void Next()
		{
			TryDisplay(m_DisplayedIndex+1, true);
		}
		public void Previous()
		{
			TryDisplay(m_DisplayedIndex-1, true);
		}
		public void NextNoLoop()
		{
			TryDisplay(m_DisplayedIndex+1, false);
		}
		public void PreviousNoLoop()
		{
			TryDisplay(m_DisplayedIndex-1, false);
		}
		#endregion
		
		#region Methods
		public override void OnDoubleClick(Mobile from)
		{
			if(from.AccessLevel>=AccessLevel.Administrator)
				from.SendGump( new DynamicGump(from, this));
		}
		
		private void DisplayDecorum(DecorumDefinition def)
		{
			if(!def.Displayed)
			{
				ClearDisplayedDef();
				
				def.Display();
			}
		}
		
		private void ClearDisplayedDef()
		{
			if(m_Displayed!=null)
				m_Displayed.Clear();
			
			m_Definitions.Where(d=>d.Displayed).ToList().ForEach(d=>d.Displayed = false);//sanity
		}

		private void TryDisplay(FlipTo flip)
		{
			switch(flip)
			{
				case FlipTo.First:
					{
						First();
						break;
					}
				case FlipTo.Last:
					{
						Last();
						break;
					}
				case FlipTo.Next:
					{
						Next();
						break;
					}
				case FlipTo.Previous:
					{
						Previous();
						break;
					}
				case FlipTo.NextNoLoop:
					{
						NextNoLoop();
						break;
					}
				case FlipTo.PreviousNoLoop:
					{
						PreviousNoLoop();
						break;
					}
			}
		}
		
		private void TryDisplay(int index, bool loop)
		{
			if(m_Empty)
				return;
			
			if(!loop)
			{
				if(index>=0 && index<m_DefCount)
				{
					DisplayDecorum(m_Definitions[index]);
					
					return;
				}
				
				return;
			}
			
			if(index<0)
				index = m_DefCount-1;
			
			if(index==m_DefCount)
				index = 0;
			
			DisplayDecorum(m_Definitions[index]);
			
			return;
		}
		#endregion
		
		#region Serial
		public Decorum( Serial serial ) : base( serial )
		{
		}
		
		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );
			writer.Write( (int) 1 );
			
			writer.Write( m_Definitions.Count );
			foreach(DecorumDefinition def in m_Definitions)
			{
				def.Serialize(writer);
			}
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );
			int version = reader.ReadInt();
			
			int count = reader.ReadInt();
			for(int i=0;i<count;i++)
			{
				m_Definitions.Add(new DecorumDefinition(reader));
			}
		}
		
		#endregion
		
		#region Gump
		
		#region SelectDefinition
		[GumpElement(DisplayMode.LabelData)]
		public int NbLabel;
		public string GetData_NbLabel()
		{
			if(m_DefCount>0)
				return "This Decorum contains "+m_DefCount.ToString()+" definition"+(m_DefCount>1?"s":"");
			
			return "This Decorum is empty";
		}
		
		[GumpElement(DisplayMode.List)]
		public int DefList=0;
		public bool IsActive_DefList()
		{
			return !m_Empty;
		}
		public string GetData_DefList()
		{
			return m_Definitions[DefList].Name;
		}
		public void CallBack_DefList_Up(Mobile from)
		{
			if(DefList<m_DefCount-1)
				DefList++;
			
			from.SendGump(new DynamicGump(from, this));
		}
		public void CallBack_DefList_Down(Mobile from)
		{
			if(DefList>0)
				DefList--;
			
			from.SendGump(new DynamicGump(from, this));
		}
		public void CallBack_DefList(Mobile from)
		{
			m_SelectedDef = m_Definitions[DefList];
			
			from.SendGump(new DynamicGump(from, this));
		}
		#endregion
		
		#region AddDefinition
		[GumpElement(DisplayMode.ButtonLabel,"Add a new definition")]
		public int AddDef;
		public void CallBack_AddDef(Mobile from)
		{
			from.SendMessage("Enter new DecorumDefinition's name ...");
			
			from.Prompt = new CallBackPrompt(this,"AddDecorumDefinition");
		}
		public void AddDecorumDefinition(Mobile from, string txt)
		{
			DecorumDefinition def = new DecorumDefinition(txt, this);
			
			m_Definitions.Add( def );
			
			DefList = m_Definitions.IndexOf(def);
			
			from.SendGump(new DynamicGump(from, def));
		}
		#endregion
		
		#region ManageDef
		[GumpElement(DisplayMode.ButtonLabelData)]
		public int ManageDef;
		public bool IsActive_ManageDef()
		{
			return !m_Empty && m_SelectedDef!=null;
		}
		public string GetData_ManageDef()
		{
			return "Manage Selected Definition : '"+m_SelectedDef.Name+"'";
		}
		public void CallBack_ManageDef(Mobile from)
		{
			from.SendGump( new DynamicGump(from, m_SelectedDef));
		}
		#endregion
		
		#region DisplaySelected
		[GumpElement(DisplayMode.ButtonLabelData)]
		public int DisplaySelected;
		public bool IsActive_DisplaySelected()
		{
			return !m_Empty && m_SelectedDef!=null && (m_Displayed==null || m_Displayed!=m_SelectedDef);
		}
		public string GetData_DisplaySelected()
		{
			return "Display Selected Definition : '"+m_SelectedDef.Name+"'";
		}
		public void CallBack_DisplaySelected(Mobile from)
		{
			DisplayDecorum(m_SelectedDef);
			
			from.SendGump(new DynamicGump(from, this));
		}
		#endregion
		
		#region ShowNothing
		[GumpElement(DisplayMode.ButtonLabel,"Show Nothing")]
		public int ShowNothing;
		public bool IsActive_ShowNothing()
		{
			return m_Displayed!=null;
		}
		public void CallBack_ShowNothing(Mobile from)
		{
			ClearDisplayedDef();
			
			from.SendGump(new DynamicGump(from, this));
		}
		#endregion
		
		#region DeleteDefinition
		[GumpElement(DisplayMode.Blank)]
		public int Blank;
		[GumpElement(DisplayMode.ButtonLabelData)]
		public int DeleteDef;
		public bool IsActive_DeleteDef()
		{
			return !m_Empty && m_SelectedDef!=null;
		}
		public string GetData_DeleteDef()
		{
			return "Definitivly Delete Definition : '"+m_SelectedDef.Name+"'";
		}
		public void CallBack_DeleteDef(Mobile from)
		{
			if(m_DefCount==1)
			{
				DefList = 0;
				m_Definitions.Clear();
			}
			else
			{
				DefList = Math.Max(0,DefList-1);
				
				m_Definitions.Remove(m_SelectedDef);
				
				m_SelectedDef = null;
			}
			
			from.SendGump( new DynamicGump(from, this));
		}
		#endregion
		
		#endregion
	}
	
	[GumpHeader(Profile.Paper,IsClosable.False,"Decorum Definition")]
	public class DecorumDefinition
	{
		#region ...ctor
		public DecorumDefinition(string name, Decorum deco)
		{
			m_Parent = deco;
			m_Name = name;
			m_Map = deco.Map;
		}
		#endregion
		
		#region Private
		private Decorum m_Parent;
		private string m_Name="Unknown";
		private List<DecorumElement> m_Elements = new List<DecorumElement>();
		private bool m_Empty { get { return m_Elements.Count==0; } }
		private bool m_Displayed = false;
		private Map m_Map;
		#endregion
		
		#region Public
		[GumpElement(DisplayMode.LabelData)]
		public string Name
		{
			get { return m_Name; }
		}
		public string GetData_Name()
		{
			return "Name : "+m_Name;
		}
		
		public List<DecorumElement> Elements
		{
			get { return m_Elements; }
		}
		public bool Displayed
		{
			get { return m_Displayed; }
			set { m_Displayed = value; }
		}
		#endregion
		
		#region Method
		public void Clear()
		{
			m_Displayed = false;
			
			bool first = true;
			
			MapOperationSeries moveSeries = new MapOperationSeries(null, m_Map.MapID);
			
			foreach(DecorumElement element in m_Elements)
			{
				element.Clear( ref moveSeries, ref first, m_Map);
			}
			
			if(!first)
				moveSeries.DoOperation();
		}
		
		public void Display()
		{
			m_Displayed = true;
			
			bool first = true;
			
			MapOperationSeries moveSeries = new MapOperationSeries(null, m_Map.MapID);
			
			foreach(DecorumElement element in m_Elements)
			{
				element.Display( ref moveSeries, ref first, m_Map);
			}
			
			if(!first)
				moveSeries.DoOperation();
		}
		
		private void DeleteTarget(IPoint3D target, Map map)
		{
			if(target is LandTarget)
				new SetLandID(target.X, target.Y, map.MapID, 2).DoOperation();
			else if(target is StaticTarget)
				new DeleteStatic(map.MapID,(StaticTarget)target).DoOperation();
			else if(target is AddonComponent)
				((AddonComponent)target).Addon.Delete();
			else
				((Item)target).Delete();
		}
		#endregion
		
		#region Serial
		public void Serialize( GenericWriter writer )
		{
			writer.Write( (int) 1 );
			
			writer.Write( m_Name );
			
			writer.Write( m_Elements.Count );
			foreach(DecorumElement e in m_Elements)
			{
				e.Serialize(writer);
			}
			
			writer.Write( m_Displayed );
			
			writer.Write( m_Map );
		}

		public DecorumDefinition( GenericReader reader )
		{
			int version = reader.ReadInt();
			
			m_Name = reader.ReadString();
			
			int count = reader.ReadInt();
			for(int i=0;i<count;i++)
			{
				m_Elements.Add(new DecorumElement(reader));
			}
			
			m_Displayed = reader.ReadBool();
			
			m_Map = reader.ReadMap();
		}
		
		#endregion
		
		#region Gump
		
		#region Rename
		[GumpElement(DisplayMode.ButtonLabel,"Rename")]
		public int RenameElement;
		public void CallBack_RenameElement(Mobile from)
		{
			from.SendMessage("Enter new name ...");
			
			from.Prompt = new CallBackPrompt(this,"OnRenamed");
		}
		public void OnRenamed(Mobile from, string txt)
		{
			m_Name = txt;
			
			from.SendGump(new DynamicGump(from, this));
		}
		#endregion
		
		#region Add
		[GumpElement(DisplayMode.ButtonLabel,"Add elements")]
		public int AddElement;
		public void CallBack_AddElement(Mobile from)
		{
			from.SendMessage("Target elements to add ... (Esc to stop)");
			
			from.Target = new CallBackTarget(this,"OnElementAdded", new object[]{});
		}
		public void OnElementAdded(Mobile from, IPoint3D target, object[] data)
		{
			string message = "undefined error";
			
			if(DecorumElement.Create(target, ref m_Elements, ref message))
			{
				DeleteTarget(target, from.Map);
				
				from.Target = new CallBackTarget(this,"OnElementAdded", new object[]{});
				
				from.SendMessage(message);
			}
			else
			{
				from.SendMessage(message);
				
				from.SendGump( new DynamicGump(from, this));
			}
		}
		#endregion
		
		#region Delete
		[GumpElement(DisplayMode.ButtonLabel,"Remove elements")]
		public int DeleteElement;
		public bool IsActive_DeleteElement()
		{
			return !m_Empty;
		}
		public void CallBack_DeleteElement(Mobile from)
		{
			//CallBack_DisplayIG(from);
			
			from.SendMessage("Target elements to delete ... (Esc to stop)");
			
			from.Target = new CallBackTarget(this,"OnElementDeleted", new object[]{});
		}
		public void OnElementDeleted(Mobile from, IPoint3D target, object[] data)
		{
			string message = "undefined error";
			
			if(Remove(DecorumElement.Find(target, m_Elements), ref message))
			{
				DecorumElement.ResultMessage(target, ref message, false);
				
				from.Target = new CallBackTarget(this,"OnElementDeleted", new object[]{});
			}
			
			from.SendMessage(message);
			
			from.SendGump( new DynamicGump(from, this));
		}
		private bool Remove(DecorumElement element, ref string message)
		{
			if(element!=null)
			{
				if(m_Elements.Contains(element))
				{
					m_Elements.Remove(element);
					
					return true;
				}
			}
			
			message = "That element is not in "+Name;
			
			return false;
		}
		#endregion
		
		#region Previous
		[GumpElement(DisplayMode.Previous)]
		public int Previous;
		public void CallBack_Previous(Mobile from)
		{
			from.CloseGump(typeof(DynamicGump));
			
			from.SendGump( new DynamicGump(from, m_Parent));
		}
		#endregion
		
		#endregion
	}
	
	public class DecorumElement
	{
		#region Static
		public static bool Create(IPoint3D target, ref List<DecorumElement> elements, ref string message)
		{
			if(AintValid(target, ref message))
				return false;
			
			if(AlreadyExist(target, elements, ref message))
				return false;

			if(CheckAddon(target, elements, ref message))
				return false;
			
			elements.Add( new DecorumElement(target) );
			
			ResultMessage(target, ref message, true);
			
			return true;
		}
		
		private static bool AintValid(IPoint3D target, ref string message)
		{
			if( (target is StaticTarget) || (target is LandTarget) )
				return false;
			
			if(target is Item)
			{
				Item item = (Item)target;
				
				if(CheckBlackList(item.GetType(), ref message))
					return true;
				
				if(!(item.Visible))
				{
					message = "Non visible items not allowed !";
					
					return true;
				}
				
				return false;
			}
			
			message = "Bad targeted type !";
			
			return true;
		}
		
		private static bool CheckBlackList(Type t, ref string message)
		{
			for(int i=0;i<BlackList.Types.Length;i++)
			{
				if(t==BlackList.Types[i])
				{
					message = t.ToString().Split('.').Last()+" is not allowed !";
					
					return true;
				}
			}
			
			return false;
		}
		
		public static bool AlreadyExist(IPoint3D target, List<DecorumElement> elements, ref string message)
		{
			if(Find(target,elements)!=null)
			{
				message = ((target is LandTarget)?"That LandTile":"That Item")+" is already set in that DecorumDefinition !";
				
				return true;
			}
			
			return false;
		}
		
		//obsolete ?
		private static bool CheckAddon(IPoint3D target, List<DecorumElement> elements, ref string message)
		{
			if(target is AddonComponent)
			{
				AddonComponent ac = (AddonComponent)target;
				BaseAddon addon = ac.Addon;
				
				if(elements.Count(e=>e.m_Addon && e.m_Type==addon.GetType() && e.m_Loc==addon.Location)>0)
				{
					message = "AddonComponent : This Addon is already strored in that list !";
					
					return true;
				}
			}
			
			return false;
		}
		
		public static DecorumElement Find(IPoint3D target, List<DecorumElement> elements)
		{
			Point3D loc = new Point3D(target);
			
			if(target is LandTarget)
				return elements.FirstOrDefault(d=>d.m_Land && d.m_Loc==loc);
			else
				return elements.FirstOrDefault(d=>!(d.m_Land) && d.m_Loc==loc && d.m_ID==GetID(target));
		}
		
		public static void ResultMessage(IPoint3D target, ref string message, bool adding)
		{
			message = (adding?"Adding ":"Deleting ");
			
			if(target is LandTarget)
				message+="LandTile at";
			else if( target is StaticTarget)
				message+="StaticItem at";
			else
			{
				Item t = (Item)target;
				
				message+=t.GetType().ToString().Split('.').Last()+" at";
			}
			
			message += target.X.ToString()+"/"+target.Y.ToString()+"/"+target.Z.ToString();
		}
		
		private static int GetID(IPoint3D target)
		{
			if(target is LandTarget)
				return ((LandTarget)target).TileID;
			else if(target is StaticTarget)
				return ((StaticTarget)target).ItemID;
			else
				return ((Item)target).ItemID;
			
		}
		#endregion
		
		#region ...ctor
		public DecorumElement(IPoint3D target)		{
			m_Land = (target is LandTarget);
			
			if(target is Item)
			{
				Item item = (Item)target;
				
				if(target is AddonComponent)
				{
					m_Addon = true;
					
					BaseAddon addon = ((AddonComponent)target).Addon;
					
					m_Type = addon.GetType();
					
					m_Loc = addon.Location;
				}
				else m_Type = item.GetType();
				
				m_Hue = item.Hue;
				
				m_Name = item.Name;
			}
			
			m_ID = GetID(target);
			
			if(!m_Addon)
				m_Loc = new Point3D(target);
		}
		#endregion
		
		#region Private
		private bool m_Land;
		private bool m_Addon;
		private Type m_Type;
		private int m_ID;
		private Point3D m_Loc;
		private int m_Hue;
		private string m_Name;
		#endregion
		
		#region Method
		public void Display(ref MapOperationSeries moveSeries, ref bool first, Map map)
		{
			if(m_Land)
			{
				if(first)
				{
					moveSeries = new MapOperationSeries(new SetLandID(m_Loc.X,m_Loc.Y,map.MapID,m_ID), map.MapID);
					
					first = false;
				}
				else
					moveSeries.Add(new SetLandID(m_Loc.X,m_Loc.Y,map.MapID,m_ID));
			}
			else if(m_Type!=null)
			{
				Item result = (Item)Activator.CreateInstance(m_Type);
				
				if(result!=null)
				{
					result.Hue = m_Hue;
					
					result.Name = m_Name;
					
					result.ItemID = m_ID;
					
					result.MoveToWorld(m_Loc,map);
					
					result.Movable = false;
				}
			}
			else
			{
				if(first)
				{
					moveSeries = new MapOperationSeries(new AddStatic(map.MapID,m_ID,0,m_Loc.X,m_Loc.Y,0), map.MapID);
					
					first = false;
				}
				else
					moveSeries.Add(new AddStatic(map.MapID,m_ID,0,m_Loc.X,m_Loc.Y,0));
			}
		}
		
		public void Clear(ref MapOperationSeries moveSeries, ref bool first, Map map)
		{
			if(m_Land)
			{
				if(first)
				{
					moveSeries = new MapOperationSeries(new SetLandID(m_Loc.X,m_Loc.Y,map.MapID,2), map.MapID);
					
					first = false;
				}
				else
					moveSeries.Add(new SetLandID(m_Loc.X,m_Loc.Y,map.MapID,2));
			}
			else if(m_Type!=null)
			{
				Item todelete = FindItem(map);
				
				if(todelete!=null)
					todelete.Delete();
			}
			else
			{
				if(first)
				{
					moveSeries = new MapOperationSeries(new DeleteStatic(map.MapID,new StaticTarget(new Point3D(m_Loc.X,m_Loc.Y,0),m_ID)), map.MapID);
					
					first = false;
				}
				else
					moveSeries.Add(new DeleteStatic(map.MapID,new StaticTarget(new Point3D(m_Loc.X,m_Loc.Y,0),m_ID)));
			}
		}
		
		private Item FindItem(Map map)
		{
			IPooledEnumerable items = map.GetItemsInRange(m_Loc,0);
			foreach(Item item in items)
			{
				if(item.GetType()==m_Type && item.Hue==m_Hue && item.Name==m_Name && item.ItemID==m_ID && item.Location.Z==m_Loc.Z)
					return item;
			}
			
			items.Free();
			
			return null;
		}
		#endregion
		
		#region Serial
		public void Serialize( GenericWriter writer )
		{
			writer.Write( (int) 1 );
			
			writer.Write( m_Land );
			
			if(m_Type!=null)
				writer.Write( m_Type.FullName );
			else writer.Write( "null" );
			
			writer.Write( m_Hue );
			
			writer.Write( m_Name );
			
			writer.Write( m_ID );
			
			writer.Write( m_Loc );
			
			writer.Write( m_Addon );
		}

		public DecorumElement( GenericReader reader )
		{
			int version = reader.ReadInt();
			
			m_Land = reader.ReadBool();
			
			string type = reader.ReadString();
			if(type!="null")
				m_Type = ScriptCompiler.FindTypeByFullName(type);
			
			m_Hue = reader.ReadInt();
			
			m_Name = reader.ReadString();
			
			m_ID = reader.ReadInt();
			
			m_Loc = reader.ReadPoint3D();
			
			m_Addon = reader.ReadBool();
		}
		
		#endregion
	}
}
// Panther Family
// a RunUO ver 2.0 Script
// Written by David 
// last edited 6/17/06
//modifyed by Neshobsa 

using System;
using Server.Mobiles;
using System.Collections;

namespace Server.Mobiles
{
	[CorpseName( "a panther corpse" )]
	public class MotherPanther : BaseCreature
	{
		private ArrayList m_cubs;
		int cubCount = Utility.RandomMinMax( 2, 5 );

		public override int Meat{ get{ return 1; } }
		public override int Hides{ get{ return 3; } }
		public override FoodType FavoriteFood{ get{ return FoodType.Meat; } }
		public override PackInstinct PackInstinct{ get{ return PackInstinct.Canine; } }
		public override bool CanRegenHits{ get{ return true; } }

		[CommandProperty( AccessLevel.GameMaster )]
		public bool RespawnCubss
		{
			get{ return false; }
			set{ if( value ) SpawnBabies(); }
		}

		[Constructable]
        public MotherPanther() : base(AIType.AI_Melee, FightMode.Aggressor, 10, 1, 0.1, 0.3)
		{
			Name = "a mother panther";
			Body = 0xD6;
			BaseSoundID = 0x462;

			SetStr( 91, 110 );
			SetDex( 76, 95 );
			SetInt( 31, 50 );

			SetHits( 42, 68 );
			SetMana( 0 );

			SetDamage( 11, 21 );

			SetDamageType( ResistanceType.Physical, 100 );

			SetResistance( ResistanceType.Physical, 15, 25 );
			SetResistance( ResistanceType.Fire, 1, 10 );
			SetResistance( ResistanceType.Cold, 20, 25 );
			SetResistance( ResistanceType.Poison, 10, 15 );
			SetResistance( ResistanceType.Energy, 10, 15 );

			SetSkill( SkillName.MagicResist, 30.6, 45.0 );
			SetSkill( SkillName.Tactics, 50.1, 70.0 );
			SetSkill( SkillName.Wrestling, 60.1, 75.0 );

			Fame = 300;
			Karma = 0;

			VirtualArmor = 22;

			Tamable = true;
                                                     ControlSlots = 1;
                                                      MinTameSkill = 90.9;

			m_cubs = new ArrayList();
			Timer m_timer = new PantherFamilyTimer( this );
			m_timer.Start();
		}

		public override bool OnBeforeDeath()
		{	
			foreach( Mobile m in m_cubs )
			{	
				if( m is PantherCub && m.Alive && ((PantherCub)m).ControlMaster != null )
					m.Kill();
			}
			
			return base.OnBeforeDeath();
		}
		
		public void SpawnBabies()
		{

			Defrag();
			int family = m_cubs.Count;

			if( family >= cubCount )
				return;

			//Say( "family {0}, should be {1}", family, cubCount );

			Map map = this.Map;

			if ( map == null )
				return;

			int hr = (int)((this.RangeHome + 1) / 2);

			for ( int i = family; i < cubCount; ++i )
			{
				PantherCub cub = new PantherCub();

				bool validLocation = false;
				Point3D loc = this.Location;

				for ( int j = 0; !validLocation && j < 10; ++j )
				{
					int x = X + Utility.Random( 5 ) - 1;
					int y = Y + Utility.Random( 5 ) - 1;
					int z = map.GetAverageZ( x, y );

					if ( validLocation = map.CanFit( x, y, this.Z, 16, false, false ) )
						loc = new Point3D( x, y, Z );
					else if ( validLocation = map.CanFit( x, y, z, 16, false, false ) )
						loc = new Point3D( x, y, z );
				}

				cub.Mother = this;
				cub.Team = this.Team;
				cub.Home = this.Location;
				cub.RangeHome = ( hr > 4 ? 4 : hr );
				
				cub.MoveToWorld( loc, map );
				m_cubs.Add( cub );
			}
		}

		protected override void OnLocationChange( Point3D oldLocation )
		{

			try
			{
				foreach( Mobile m in m_cubs )
				{	
					if( m is PantherCub && m.Alive && ((PantherCub)m).ControlMaster == null )
					{
						((PantherCub)m).Home = this.Location;
					}
				}
			}
			catch{}

			base.OnLocationChange( oldLocation );
		}
		
		public void Defrag()
		{
			for ( int i = 0; i < m_cubs.Count; ++i )
			{
				try
				{
					object o = m_cubs[i];

					PantherCub cub = o as PantherCub;

					if ( cub == null || !cub.Alive )
					{
						m_cubs.RemoveAt( i );
						--i;
					}

					else if ( cub.Controlled || cub.IsStabled )
					{
						cub.Mother = null;
						m_cubs.RemoveAt( i );
						--i;
					}
				}
				catch{}
			}
		}

		public override void OnDelete()
		{
			Defrag();

			foreach( Mobile m in m_cubs )
			{	
				if( m.Alive && ((PantherCub)m).ControlMaster == null )
					m.Delete();
			}

			base.OnDelete();
		}

		public MotherPanther(Serial serial) : base(serial)
		{
			m_cubs = new ArrayList();
			Timer m_timer = new PantherFamilyTimer( this );
			m_timer.Start();
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize(writer);
			writer.Write((int) 0);
			writer.WriteMobileList( m_cubs, true );
		}

		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
			m_cubs = reader.ReadMobileList();
		}
	}

	[CorpseName( "a young panther corpse" )]
	public class PantherCub : BaseCreature
	{
		public override int Meat{ get{ return 1; } }
		public override FoodType FavoriteFood{ get{ return FoodType.Meat; } }
		public override PackInstinct PackInstinct{ get{ return PackInstinct.Canine; } }

		private MotherPanther m_mommy;

		[CommandProperty( AccessLevel.GameMaster )]
		public MotherPanther Mother
		{
			get{ return m_mommy; }
			set{ m_mommy = value; }
		}

		[Constructable]
        public PantherCub() : base(AIType.AI_Animal, FightMode.Aggressor, 10, 1, 0.2, 0.4)
		{
			Name = "a panther cub";
			Body = 0xC9;
			BaseSoundID = 0x69;

			SetStr( 37, 47 );
			SetDex( 38, 53 );
			SetInt( 39, 47 );

			SetHits( 17, 42 );
			SetMana( 0 );

			SetDamage( 4, 7 );

			SetDamageType( ResistanceType.Physical, 100 );

			SetResistance( ResistanceType.Physical, 10, 15 );

			SetSkill( SkillName.MagicResist, 22.1, 47.0 );
			SetSkill( SkillName.Tactics, 19.2, 31.0 );
			SetSkill( SkillName.Wrestling, 19.2, 46.0 );

			Fame = 100;
			Karma = 100;

			VirtualArmor = 10;

			Tamable = true;
			ControlSlots = 1;
			MinTameSkill = 53.1;
		}

		public override void OnCombatantChange()
		{
			if( Combatant != null && Combatant.Alive && m_mommy != null && m_mommy.Combatant == null )
				m_mommy.Combatant = Combatant;
		}

		public PantherCub(Serial serial) : base(serial)
		{
		}

		public override void Serialize(GenericWriter writer)
		{
			base.Serialize( writer );
			writer.Write( (int) 0 );
			writer.Write( m_mommy );
		}

		public override void Deserialize(GenericReader reader)
		{
			base.Deserialize(reader);
			int version = reader.ReadInt();
			m_mommy = (MotherPanther)reader.ReadMobile();
		}
	}

	public class PantherFamilyTimer : Timer
	{
		private MotherPanther m_from;

		public PantherFamilyTimer( MotherPanther from  ) : base( TimeSpan.FromMinutes( 1 ), TimeSpan.FromMinutes( 20 ) )
		{
			Priority = TimerPriority.OneMinute; 
			m_from = from;
		}

		protected override void OnTick()
		{
			if ( m_from != null && m_from.Alive )
				m_from.SpawnBabies();
			else
				Stop();
		}
	}
}
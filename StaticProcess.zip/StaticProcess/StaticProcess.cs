﻿/*
 * Crée par SharpDevelop.
 * Gargouille
 * Date: 22/11/2014
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using Server;
using Server.Targeting;

using UltimaLive;

namespace Server.Items
{
	public interface IStaticProcessable
	{
		int OnMapStaticID { get; }
	}
	
	public static class StaticProcess
	{
		#region Private
		private static string SavePath { get { return Path.Combine(Core.BaseDirectory, "StaticProcess"); } }
		
		private static Dictionary<Type, int> StaticTypesIds = new Dictionary<Type, int>();
		
		private static Dictionary<int,List<StaticProcessInfo>> MapLocToRespawn = new Dictionary<int, List<StaticProcessInfo>>();
		
		private static void OnSave(WorldSaveEventArgs e)
		{
			Respawn();
			
			if (!Directory.Exists(SavePath))
				Directory.CreateDirectory(SavePath);
			
			Map.AllMaps.Where(m=>MapLocToRespawn.ContainsKey(m.MapID)).ForEach(m=>
			                                                                   {
			                                                                   	GenericWriter writer = new BinaryFileWriter(Path.Combine(SavePath, "SaveMap." + m.MapID), true);
			                                                                   	
			                                                                   	MapLocToRespawn[m.MapID].ForEach(s=>s.Serialize(writer));
			                                                                   	
			                                                                   	writer.Close();
			                                                                   });
		}
		
		private static void OnLoad()
		{
			Map.AllMaps.ForEach(m=>{ MapLocToRespawn.Add(m.MapID, new List<StaticProcessInfo>()); });
			
			MapLocToRespawn.ForEach(kvp=>
			                        {
			                        	string filename = Path.Combine(SavePath, "SaveMap." + kvp.Key);
			                        	
			                        	FileInfo treeFileInfo = new FileInfo(filename);

			                        	if (treeFileInfo.Exists && Map.AllMaps.Count(m=>m.MapID==kvp.Key)>0)
			                        	{
			                        		using (FileStream fs = new FileStream(filename, FileMode.Open))
			                        		{
			                        			using (BinaryReader br = new BinaryReader(fs))
			                        			{
			                        				GenericReader reader = new BinaryFileReader(br);

			                        				while (fs.Position < fs.Length)
			                        				{
			                        					kvp.Value.Add(new StaticProcessInfo(reader));
			                        				}
			                        			}
			                        		}
			                        	}
			                        });
			
			
			Respawn();
		}
		
		private static void Respawn()
		{
			MapLocToRespawn.ForEach(kvp=>
			                        {
			                        	MapOperationSeries moveSeries = new MapOperationSeries(null, kvp.Key);
			                        	bool first = true;

			                        	kvp.Value.Where(s=>s.Date<DateTime.Now).ForEach(spi=>{
			                        	                                                	if(first)
			                        	                                                	{
			                        	                                                		moveSeries = new MapOperationSeries(new AddStatic( kvp.Key, spi.ItemID,0,spi.X,spi.Y,0), kvp.Key);
			                        	                                                		
			                        	                                                		first = false;
			                        	                                                	}
			                        	                                                	else
			                        	                                                		moveSeries.Add(new AddStatic( kvp.Key, spi.ItemID,0,spi.X,spi.Y,0));
			                        	                                                	
			                        	                                                	kvp.Value.Remove(spi);
			                        	                                                });
			                        	if(!first)
			                        		moveSeries.DoOperation();
			                        });
		}
		
		private static Timer m_Timer;
		private class RespawnTimer : Timer
		{
			public RespawnTimer():base(TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1))
			{
				
			}
			
			protected override void OnTick()
			{
				StaticProcess.Respawn();
			}
		}
		
		private class StaticProcessInfo
		{
			private DateTime m_Date;
			public DateTime Date
			{
				get { return m_Date; }
			}
			
			private int m_ItemID;
			public int ItemID
			{
				get { return m_ItemID; }
			}
			
			private Point3D m_Location;
			public int X { get { return m_Location.X; } }
			public int Y { get { return m_Location.Y; } }
			public int Z { get { return m_Location.Z; } }
			
			public StaticProcessInfo(StaticTarget target, TimeSpan delay)
			{
				m_Location = target.Location;
				
				m_ItemID = target.ItemID;
				
				m_Date = DateTime.Now+delay;
			}
			
			public void Serialize(GenericWriter writer)
			{
				writer.Write( 0 );//version
				
				writer.Write( m_Date );
				
				writer.Write( m_ItemID );
				
				writer.Write( m_Location );
				
			}
			
			public StaticProcessInfo(GenericReader reader)
			{
				int version = reader.ReadInt();
				
				m_Date = reader.ReadDateTime();
				
				m_ItemID = reader.ReadInt();
				
				m_Location = reader.ReadPoint3D();
			}
		}
		
		#endregion
		
		#region Init
		public static void Configure()
		{
			EventSink.WorldSave += new WorldSaveEventHandler(OnSave);
			EventSink.WorldLoad += new WorldLoadEventHandler(OnLoad);
		}
		
		public static void Initialize()
		{
			ScriptCompiler.Assemblies[0].GetTypes().Where(t=>t.IsSubclassOf(typeof(Item)) && t.GetInterface("IStaticProcessable")!=null && !t.IsAbstract).ForEach(t=>StaticTypesIds.Add(t,((IStaticProcessable)(Activator.CreateInstance(t))).OnMapStaticID));
			
			/*
			foreach(Type t in ScriptCompiler.Assemblies[0].GetTypes())
			{
				if(t.IsSubclassOf(typeof(Item)) && t.GetInterface("IStaticProcessable")!=null && !t.IsAbstract)
				{
					IStaticProcessable i = (IStaticProcessable)Activator.CreateInstance(t);
					
					StaticTypesIds.Add(t,i.OnMapStaticID);
				}
			}*/
						
			if(m_Timer==null)
				m_Timer = new RespawnTimer();
			
			m_Timer.Start();
		}
		#endregion
		
		#region Public
		public static Type GetExtractType(Mobile from, object target)
		{
			Type result = null;
			
			if(target is StaticTarget)
				StaticTypesIds.Where(kvp=>kvp.Value==((StaticTarget)target).ItemID).ForEach(kvp=>result=kvp.Key);
			
			return result;
		}
		
		public static Item ExtractItemFromTarget(Mobile from, object target)
		{
			Item i = null;
			
			Type t = GetExtractType(from, target);
			
			if(t!=null)
				i =  (Item)(Activator.CreateInstance(t));
			
			return i;
		}
		
		public static void Delete(Map m, StaticTarget st)
		{
			int z=0;
			
			m.Tiles.GetStaticTiles(st.X,st.Y).Where(t=>t.ID==st.ItemID).ForEach(t=>z=t.Z);
			
			new DeleteStatic(m.MapID,new StaticTarget(new Point3D(st.X,st.Y,z),st.ItemID)).DoOperation();
		}
		
		public static bool UnFreeze(Mobile from, ref object target)
		{
			Item i = ExtractItemFromTarget(from, target);
			
			if(i!=null)
			{
				Delete(from.Map,(StaticTarget)target);
				
				i.MoveToWorld(((StaticTarget)target).Location,from.Map);
				
				target = i;
				
				return true;
			}
			
			return false;
		}
		
		public static void Respawn(Map m, object o, int id, TimeSpan delay)
		{
			if(o is IPoint3D)
				Respawn(m,(IPoint3D)o,id,delay);
		}
		
		public static void Respawn(Map m, IPoint3D loc, int id, TimeSpan delay)
		{
			Respawn(m, new StaticTarget(new Point3D(loc),id),delay);
		}
		
		public static void Respawn(Map m, StaticTarget st, TimeSpan delay)
		{
			Delete(m,st);
			
			MapLocToRespawn[m.MapID].Add(new StaticProcessInfo(st, delay));
		}
		#endregion
	}
}
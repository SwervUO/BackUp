﻿/*
 * 
 * By Gargouille
 * Date: 22/12/2013
 * 
 * 
 */

using System;
using System.Collections.Generic;
using Server.Mobiles;
using Server.Targeting;
using Server.Engines;
using Server.Commands;

namespace Server.Items
{
	public class PanierRecolte : Basket
	{
		#region Command
		public static void Initialize()
		{
			CommandSystem.Register( "Recolter", AccessLevel.Player, new CommandEventHandler( Recolter_OnCommand ) );
		}
		
		private static void Recolter_OnCommand( CommandEventArgs e )
		{
			Mobile m = e.Mobile;
			
			Backpack pack = (Backpack)m.Backpack;
			
			if(pack!=null)
			{
				PanierRecolte panier = (PanierRecolte)pack.FindItemByType(typeof(PanierRecolte));
				
				if(panier!=null)
					panier.Recolter(m);
				else
					m.SendMessage("Vous devez avoir un panier afin de pouvoir récolter !");
			}
		}
		
		#endregion
		
		[Constructable]
		public PanierRecolte()
		{
		}
		
		public static SkillName MainSkill { get { return SkillName.Herding; } }
		
		private static TimeSpan RecolteDuration = TimeSpan.FromSeconds(3);
		
		public void Recolter(Mobile from)
		{
			from.BeginTarget( 1, false, TargetFlags.None, new TargetCallback( StartRecolte ) );
		}
		
		private void StartRecolte( Mobile from, object obj )
		{
			if(from.BeginAction(typeof(PanierRecolte)))
			{
				Item item = StaticProcess.ExtractItemFromTarget(from, obj);
				
				if(item!=null && item is Herbe)
				{
					Herbe herbe = (Herbe)item;
					
					StaticTarget st = (StaticTarget)obj;
					
					from.Direction = from.GetDirectionTo(st);
					
					from.ClearHands();
					
					from.Animate(32, 0, 2, true, true, 0);
					
					from.Emote(RandomEmote(Start));
					
					Timer.DelayCall(RecolteDuration,new TimerStateCallback(EndRecolte),new object[]{from, herbe, st});
				}
				else 
					from.EndAction(typeof(PanierRecolte));
			}
			else
				from.SendMessage("Vous êtes déjà en pleine récolte !");
		}
		
		private void EndRecolte( object state )
		{
			object[] states = (object[])state;
			
			Mobile from = (Mobile)states[0];
			Herbe herbe = (Herbe)states[1];
			StaticTarget st = (StaticTarget)states[2];
			
			if(from.CheckSkill(MainSkill,herbe.minSkill,herbe.maxSkill))
			{
				if(from.CheckSkill(MainSkill,herbe.minSkill,herbe.maxSkill))
				{
					herbe.Amount+=herbe.BonusRecolte;
					
					from.Emote(RandomEmote(BigSucces));
				}
				else
					from.Emote(RandomEmote(Succes));
				
				if(!(this.TryDropItem(from,herbe,false)))
				{
					from.SendMessage("Votre panier est plein !");
					
					herbe.MoveToWorld(from.Location,from.Map);
				}
				
				from.PlaySound(0x539);
				
			}
			else
			{
				from.Emote(RandomEmote(Fail));
				
				from.PlaySound(0x53A);
				
				herbe.Delete();
			}
						
			StaticProcess.Respawn(from.Map, st, herbe.RespawnDelay);
						
			from.EndAction(typeof(PanierRecolte));
			
			Recolter(from);
		}
		
		private string RandomEmote(string[] list)
		{
			string result ="";
			
			if(list.Length>0)
				result = list[Utility.Random(0,list.Length-1)];
			
			return result;
		}
		
		private string[] Start = new string[]
		{
			"Gratte, trie, fouille..."
		};
		
		private string[] Fail = new string[]
		{
			"Pfff raté !"
		};
		
		private string[] Succes = new string[]
		{
			"Bonne récolte..."
		};
		
		private string[] BigSucces = new string[]
		{
			"Excellente récolte..."
		};
		
		#region Serial
		public PanierRecolte( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
		#endregion
	}
}
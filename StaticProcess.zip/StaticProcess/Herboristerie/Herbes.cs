﻿/*
 * Crée par SharpDevelop.
 * Gargouille
 * Date: 21/11/2014
 */

using System;

namespace Server.Items
{
	public class FleursBlanches : Herbe
	{
		[Constructable]
		public FleursBlanches() : base (3212)
		{
			//Name = "Fleurs Blanches"; Ne pas mettre le nom
		}
		
		#region Perissable Obligatoire
		public override string Singulier{ get { return "Fleur blanche";} }
		public override string Pluriel{ get{ return "Fleurs blanches";} }
		#endregion
		
		#region Perissable Facultatif
		public override TimeSpan PeremptionDelay { get { return TimeSpan.FromHours(1);} }
		public override string Peremption{ get{ return "Moisie";} }
		public override string Peremptions{ get{ return "Moisies";} }
		#endregion
		
		#region Herbe Facultatif
		public override double minSkill{ get { return 0; } } //si pj.Skill < minSkill pas de gain de skill, trop dur
		public override double maxSkill{ get { return 120; } }// si pj.Skill > maxSkill pas de gain de skill, trop facile
		public override int BaseRecolte{ get { return 1; } }// chaque recolte reussie
		public override int BonusRecolte{ get { return 1; } }//si skillcheck reussi
		public override TimeSpan RespawnDelay { get { return TimeSpan.FromMinutes(1); } }
		#endregion
		
		#region Serial
		public FleursBlanches( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
		#endregion
	}
	
	public class PampasGrass : Herbe
	{
		[Constructable]
		public PampasGrass() : base (3237)
		{
			
		}
		
		#region Perissable Obligatoire
		public override string Singulier{ get { return "";} }
		public override string Pluriel{ get{ return "";} }
		#endregion
				
		#region Serial
		public PampasGrass( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
		#endregion
	}
	
	public class PampasGrass2 : Herbe
	{
		[Constructable]
		public PampasGrass2() : base (3268)
		{
			
		}
		
		#region Perissable Obligatoire
		public override string Singulier{ get { return "";} }
		public override string Pluriel{ get{ return "";} }
		#endregion
		
		#region Serial
		public PampasGrass2( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
		#endregion
	}
}
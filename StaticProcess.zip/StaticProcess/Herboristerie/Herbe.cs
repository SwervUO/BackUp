﻿/*
 * Crée par SharpDevelop.
 * Gargouille
 * Date: 20/11/2014
 */

using System;

namespace Server.Items
{
	public abstract class Herbe : Perissable, IStaticProcessable
	{
		public int OnMapStaticID { get{ return ItemID; } }
		
		public Herbe(int itemid) : base(itemid)
		{
			Amount = BaseRecolte;
			
			Stackable = true;
		}
		
		public override double DefaultWeight
		{
			get { return 0.1; }
		}
		
		public virtual double minSkill{ get { return 0; } }
		public virtual double maxSkill{ get { return 120; } }
		public virtual int BaseRecolte{ get { return 1; } }
		public virtual int BonusRecolte{ get { return 1; } }
		public virtual TimeSpan RespawnDelay { get { return TimeSpan.FromHours(1); } }
		
		#region Persissable
		public override TimeSpan PeremptionDelay { get { return TimeSpan.FromHours(1);} }
		public override string Peremption{ get{ return "Moisie";} }
		public override string Peremptions{ get{ return "Moisies";} }
		#endregion
		
		#region Serial
		public Herbe( Serial serial ) : base( serial )
		{
		}

		public override void Serialize( GenericWriter writer )
		{
			base.Serialize( writer );

			writer.Write( (int) 0 ); // version
		}

		public override void Deserialize( GenericReader reader )
		{
			base.Deserialize( reader );

			int version = reader.ReadInt();
		}
		#endregion
	}
}
using System;

namespace Server.Items
{
    
    public class GargishEpaulette : BaseOuterTorso
    {
		[Constructable]
		public GargishEpaulette() : this(0x455)
		{
		}

        [Constructable]
        public GargishEpaulette(int hue) : base(0x9986, hue)
        {
			Hue = 0;
            Weight = 3.0;
        }
		
		public override int LabelNumber
        {
            get
            {
                return 1123325;
            }
        }// Epaulette

        public GargishEpaulette(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}
using System;

namespace Server.Items
{
    
    public class Epaulette : BaseOuterTorso
    {
		[Constructable]
		public Epaulette() : this(0x455)
		{
		}

        [Constructable]
        public Epaulette(int hue) : base(0x9985, hue)
        {
			Hue = 0;
            Weight = 3.0;
		}
		
		public override int LabelNumber
        {
            get
            {
                return 1123325;
            }
        }// Epaulette

        public Epaulette(Serial serial)
            : base(serial)
        {
        }

        public override void Serialize(GenericWriter writer)
        {
            base.Serialize(writer);

            writer.Write((int)0); // version
        }

        public override void Deserialize(GenericReader reader)
        {
            base.Deserialize(reader);

            int version = reader.ReadInt();
        }
    }
}